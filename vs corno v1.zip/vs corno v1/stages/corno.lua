function onCreate()
	-- background shit
	makeLuaSprite('fazenda', 'corno/fazenda', -100, 0);

	addLuaSprite('fazenda', false);
	
	close(true); --For performance reasons, close this script once the stage is fully loaded, as this script won't be used anymore after loading the stage
end

